package com.rockwell;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseClientDataReader {

	public static void main(String[] args) throws IOException {
		HTable hTable = null;
		ResultScanner rs = null;
		try {
			// instantiate Configuration class
			Configuration config = HBaseConfiguration.create();

			// get connection from config
			hTable = new HTable(config, "emp");
			
			Scan scan = new Scan();
			scan.setRowPrefixFilter(Bytes.toBytes("1111"));
			
			rs = hTable.getScanner(scan);
			
			rs.forEach((Result result)->{
				String rowKey = Bytes.toString(result.getRow());
				String id = Bytes.toString(result.getValue(Bytes.toBytes("cf"), Bytes.toBytes("id")));
				String name = Bytes.toString(result.getValue(Bytes.toBytes("cf"), Bytes.toBytes("name")));
				String salary = Bytes.toString(result.getValue(Bytes.toBytes("cf"), Bytes.toBytes("sal")));
				System.out.println(rowKey+","+id+","+name+","+salary);
			});
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally {
			if(rs!=null) {
				rs.close();
			}
			if(hTable!=null) {
				hTable.close();
			}
		}
	}
}
