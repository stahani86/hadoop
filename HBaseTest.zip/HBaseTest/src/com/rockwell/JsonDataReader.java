package com.rockwell;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.htrace.fasterxml.jackson.core.JsonFactory;
import org.apache.htrace.fasterxml.jackson.core.JsonParseException;
import org.apache.htrace.fasterxml.jackson.core.JsonParser;
import org.apache.htrace.fasterxml.jackson.core.JsonToken;

public class JsonDataReader {

	public static void main(String[] args) throws JsonParseException, IOException {
		InputStreamReader reader = new FileReader(args[0]);
		//BufferedReader br = new BufferedReader(reader);
		HBaseClientDataWriter.init();
		JsonFactory jsonFactory = new JsonFactory();
		JsonParser parser = jsonFactory.createParser(reader);
		long currentRecord = 1;
		ArrayList<Employee> empList = new ArrayList<Employee>();
		try {
			while (currentRecord<=19) 
			{
				currentRecord++;
				Employee emp = new Employee();
				while (parser.nextToken() != JsonToken.END_OBJECT) {
				    String key = parser.getCurrentName();
				    if ("rowkey".equals(key)) {
				        parser.nextToken();
				        emp.setRowkey(parser.getText());
				    }
				    if ("id".equals(key)) {
				        parser.nextToken();
				        emp.setId(parser.getText());
				    }
				    if ("name".equals(key)) {
				        parser.nextToken();
				        emp.setName(parser.getText());
				    }
				    if ("sal".equals(key)) {
				        parser.nextToken();
				        emp.setSal(parser.getText());
				    }
				}
			    System.out.println("End of Iteration : "+currentRecord);
			    System.out.println(emp);
				empList.add(emp);
				if(empList.size() % 3 == 0) {
					HBaseClientDataWriter.pushToHBase(empList);
					empList.clear();
				}
			}
			if(empList.size()>0) {
				HBaseClientDataWriter.pushToHBase(empList);
			}
			empList.clear();
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		}
		parser.close();
		//br.close();
		HBaseClientDataWriter.destroy();
		reader.close();
		
	}

}
