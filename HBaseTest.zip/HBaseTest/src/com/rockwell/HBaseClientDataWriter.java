package com.rockwell;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseClientDataWriter {

	private static Configuration config = null;
	private static HTable hTable = null;

	public static void init() throws IOException {
		config = HBaseConfiguration.create();
		hTable = new HTable(config, "emp");
	}

	public static void destroy(){
		config = null;
		try {
			hTable.close();
		} catch (IOException e) {
			System.err.println("hTable.close() : "+e.getMessage());
		}
	}
	
	private static byte[] _b(String value) {
		return Bytes.toBytes(value);
	}

	public static void pushToHBase(ArrayList<Employee> empList) throws IOException {
		try {
			List<Put> puts = new ArrayList<Put>();
			empList.forEach(emp->{
				Put put = new Put(_b(emp.getRowkey()));
				put.addColumn(_b(emp.COLUMN_FAMILY), _b(emp.ID), _b(emp.getId()));
				put.addColumn(_b(emp.COLUMN_FAMILY), _b(emp.NAME), _b(emp.getName()));
				put.addColumn(_b(emp.COLUMN_FAMILY), _b(emp.SAL), _b(emp.getSal()));
				puts.add(put);
			});
			hTable.put(puts);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
