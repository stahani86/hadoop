package com.rockwell;

public class Employee {

	public final String COLUMN_FAMILY ="cf";
	public final String ROWKEY ="rowkey";
	public final String ID ="id";
	public final String NAME ="name";
	public final String SAL ="sal";
	
	private String rowkey;
	private String id;
	private String name;
	private String sal;
	
	public String getRowkey() {
		return rowkey;
	}
	public void setRowkey(String rowkey) {
		this.rowkey = rowkey;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSal() {
		return sal;
	}
	public void setSal(String sal) {
		this.sal = sal;
	}
	
	@Override
	public String toString() {
		return "Employee [rowkey=" + rowkey + ", id=" + id + ", name=" + name + ", sal=" + sal + "]";
	}
	
}
