package com.rockwell

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.col
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import scala.collection.immutable.List
import java.sql.Date
import scala.collection.mutable.ListBuffer

object WorkDayTracker {
  
  //val resultDataRecordList:ListBuffer[(Int,Date,Int,Date)] = new ListBuffer[(Int,Date,Int,Date)]
  
  def main(args: Array[String]): Unit = {
    
    val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    System.setProperty("hadoop.home.dir", "D:/others/java/winutils-master/hadoop-2.7.1")
    val spark = SparkSession.builder.master("local[*]").appName("workdayApp").getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", 20)
    spark.sparkContext.setLogLevel("ERROR")
    var ordersDF = spark.read.option("header", true).option("inferSchema", true).csv("file:///D:/Jagadeesh/parT/NavikanthUSA/incoming/4thNov2019/orders.csv")
    var calDatesDF = spark.read.option("header", true).option("inferSchema", true).csv("file:///D:/Jagadeesh/parT/NavikanthUSA/incoming/4thNov2019/cal_dates.csv")
    
    ordersDF = ordersDF.selectExpr("CAST(dmnd_plt_cd as INT) as dmnd_plt_cd", "to_date(cnfrmn_dlvry_dt) as cnfrmn_dlvry_dt", "CAST(goods_rcpt_prcsng_days as INT) as goods_rcpt_prcsng_days")
                       .orderBy("cnfrmn_dlvry_dt", "dmnd_plt_cd")
                       .na.fill(0,Seq("goods_rcpt_prcsng_days")).distinct()
    ordersDF.printSchema()
    ordersDF.show()
    
    //ordersDF.createOrReplaceTempView("orders")
    
    calDatesDF = calDatesDF.where("UPPER(TRIM(wrkg_day_ind))='X'")
    calDatesDF = calDatesDF.selectExpr("cal_cd", "to_date(cal_dt) as cal_dt", "wrkg_day_ind", " CAST(plt_cd as INT) as plt_cd",
                                       "row_number() OVER (PARTITION BY plt_cd ORDER BY cal_dt) as row_num")
    calDatesDF.printSchema()
    calDatesDF.show()
    
    //calDatesDF.createOrReplaceTempView("caldates")

    val plt_cd_DF = ordersDF.select("dmnd_plt_cd").distinct()
    val count = plt_cd_DF.count()
    println(s"No of distinct plant cds : $count")
    plt_cd_DF.show()
    val plt_cd_list = plt_cd_DF.collectAsList()
    plt_cd_list.forEach(row=>{
      val plt_cd : Int = row.getInt(row.fieldIndex("dmnd_plt_cd"))
      val ordersDataDF = ordersDF.where(col("dmnd_plt_cd")===plt_cd)
      println(s"For plt_cd=$plt_cd -> ordersDataDF.count()=${ordersDataDF.count()}")
      ordersDataDF.show
      val calDatesDataDF = calDatesDF.where(col("plt_cd")===plt_cd)
      println(s"For plt_cd=$plt_cd -> calDatesDataDF.count()=${calDatesDataDF.count()}")
      calDatesDataDF.show
      val ordersList = ordersDataDF.collect().toList
      val calDatesList = calDatesDataDF.collect().toList
      val resultDataListPerPltCd : ListBuffer[(Int,Date,Int,Date)] = captureWorkDayEntry(plt_cd, ordersList, calDatesList)
      
      import spark.implicits._      
      val resultDF = resultDataListPerPltCd.toDF("dmnd_plt_cd", "cnfrmn_dlvry_dt", "goods_rcpt_prcsng_days", "final_cal_dt")
      resultDF.coalesce(1).write.csv("file:///D:/Jagadeesh/parT/NavikanthUSA/delivery/6thNov2019/results")
      
    })
    spark.close()
  }
  
  def captureWorkDayEntry(plt_cd:Int , ordersList:List[Row], calDatesList:List[Row]):ListBuffer[(Int,Date,Int,Date)]={
    val entries : ListBuffer[(Int,Date,Int,Date)] = new  ListBuffer[(Int,Date,Int,Date)]
    ordersList.foreach(row=>{
      val cnfrmn_dlvry_dt : java.sql.Date = row.getDate(row.fieldIndex("cnfrmn_dlvry_dt"))
      val goods_rcpt_prcsng_days : Int = row.getInt(row.fieldIndex("goods_rcpt_prcsng_days"))
      val startCalDateRow : org.apache.spark.sql.Row = getNearestCalendarDateRecord(cnfrmn_dlvry_dt, calDatesList)
      val startRecordRowNum : Int = startCalDateRow.getInt(startCalDateRow.fieldIndex("row_num"))
      val finalRecordRowNum : Int = startRecordRowNum + goods_rcpt_prcsng_days
      val resultCalDate : java.sql.Date= getCalDate(finalRecordRowNum:Int, calDatesList)
      entries.append((plt_cd, cnfrmn_dlvry_dt, goods_rcpt_prcsng_days, resultCalDate))
    })
    entries
  }
  
  def getNearestCalendarDateRecord(cnfrmn_dlvry_dt:java.sql.Date, calDatesList:List[Row]):Row={
    var row : org.apache.spark.sql.Row = null
    calDatesList.foreach(row=>{
      val calDate = row.getDate(row.fieldIndex("cal_dt"))
      if(calDate.equals(cnfrmn_dlvry_dt) || calDate.after(cnfrmn_dlvry_dt))
        return row
    })
    return row;
  }
  
  def getCalDate(finalRecordRowNum:Int, calDatesList:List[Row]):java.sql.Date={
    val matchedList = calDatesList.par.filter(row=>{
      finalRecordRowNum==row.getInt(row.fieldIndex("row_num"))
    }).toList
    if(matchedList.size>0){
      val resultRow = matchedList(0)
      return resultRow.getDate(resultRow.fieldIndex("cal_dt"))
    }else
      return null;
  }
}