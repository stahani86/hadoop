package com.rockwell

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.functions.dense_rank
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.expressions.Window

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate

object WorkTester {
  
  def main(args: Array[String]): Unit = {
    
     val format = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                val now = LocalDate.now();
                val startDate = now.minusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).format(format);
                val endDate = now.minusMonths(1).with(TemporalAdjusters.lastDayOfMonth()).format(format);
   /* val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    System.setProperty("hadoop.home.dir", "D:/others/java/winutils-master/hadoop-2.7.1")
    val spark = SparkSession.builder.master("local[*]").appName("workdayApp").getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", 20)
    spark.sparkContext.setLogLevel("ERROR")
    var empDF = spark.read.option("header", true).option("inferSchema", true).option("delimiter", "|").csv("file:///D:/Jagadeesh/parT/PrasadMetLifeUSA/data.txt")
    //empDF.show
    var empNewDF = empDF.withColumn("constant", lit(1))
                        .withColumn("record_no", row_number().over(Window.orderBy("constant")))
                        .withColumn("set_no", dense_rank().over(Window.orderBy("name")))
                        .drop("constant")
                        
    empNewDF.show
    val empCols:List[String] = List("record_no", "set_no"):::empDF.columns.toList
    empNewDF = empNewDF.selectExpr(empCols:_*)
    empNewDF.show()
    
    
    
    
    
    spark.close()    */
  }
}