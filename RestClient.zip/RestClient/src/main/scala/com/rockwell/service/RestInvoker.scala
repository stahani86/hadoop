package com.rockwell.service

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder
import org.glassfish.jersey.client.ClientConfig
import com.rockwell.util.PropertyUtils

object RestInvoker {
  
  def invoke():String={
    
    val config:ClientConfig  = new ClientConfig()
    val client:Client = ClientBuilder.newClient(config);
    val target: WebTarget = client.target(getBaseURI(PropertyUtils.getProperty("baseURI")));
    val response:Response = target.path("rest")
                                    .request()
                                    .accept(MediaType.TEXT_PLAIN)
                                    .get(classOf[Response])
    response.readEntity(String.class)
  }
  
  def getBaseURI(uri:String):URI={
        return UriBuilder.fromUri(uri).build();
    }
}