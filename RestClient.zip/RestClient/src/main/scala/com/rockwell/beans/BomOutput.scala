package com.rockwell.beans

class BomOutput {
  var parentMaterial:String =_
  var parentPlant:String=_
  var componentMaterial:String=_
  var ultimateComponentPlant:String=_
  var componentQuantity:String=_
  var componentActualQuantity:String=_
  var componentUOM:String=_
  var category:String=_
  var hierarchy:String=_
}

class BomHelper {
  var parentMaterial:String =_
  var parentPlant:String=_
  var componentMaterial:String=_
  var componentPlant:String=_
  var componentSourcePlant:String=_
  var derivedSourcePlant:String=_
  var cumulativeParentQuantity:String=_
  var hierarchy:String=""
}

/*
object App{
  def main(args: Array[String]): Unit = {
    val bomHelper = new BomHelper
    if(bomHelper.quantity==0.0){
      println(true)
    }else{
      println(bomHelper.quantity)
    }
  }*/