package com.rockwell

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import org.apache.log4j.Logger
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

import com.rockwell.beans.BomHelper
import com.rockwell.util.LoggerUtils
import com.rockwell.util.PropertyUtils
import com.rockwell.util.SparkUtils

object RestClientApp {

  val log: Logger = Logger.getLogger(RestClientApp.getClass)

  def main(args: Array[String]) {
    val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    
    PropertyUtils.initProperties("application.properties")
    // Configuring for Log4j
    LoggerUtils.configure(PropertyUtils.getProperty("log4jConfigPath"))
    
    //Getting spark session
    val spark = SparkSession.builder.master("local[*]").appName("restClientApp").enableHiveSupport().getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")
    
    spark.stop();
    
    val totalTimeConsumedInSecs = (System.currentTimeMillis() - startTime) / 1000
    println(s"Total Time consumed :  $totalTimeConsumedInSecs seconds")
    print("Ended at : " + LocalDateTime.now())
  }
}