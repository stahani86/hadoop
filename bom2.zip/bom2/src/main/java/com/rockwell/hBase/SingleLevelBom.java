package com.rockwell.hBase;

public class SingleLevelBom {

	@Override
	public String toString() {
		return "SingleLevelBom [COLUMN_FAMILY=" + COLUMN_FAMILY + ", ROWKEY=" + ROWKEY + ", PRNT_MATL_ID="
				+ PRNT_MATL_ID + ", PRNT_MATL_PLT_CD=" + PRNT_MATL_PLT_CD + ", CMPNT_PER_PRNT_QTY=" + CMPNT_PER_PRNT_QTY
				+ ", PRNT_MATL_BASE_UOM=" + PRNT_MATL_BASE_UOM + ", CMPNT_MATL_ID=" + CMPNT_MATL_ID
				+ ", CMPNT_MATL_UOM=" + CMPNT_MATL_UOM + ", CMPNT_MATL_PLT_CD=" + CMPNT_MATL_PLT_CD
				+ ", CMPNT_PROCRMT_TYPE_CD=" + CMPNT_PROCRMT_TYPE_CD + ", CMPNT_SPCL_PROCRMT_TYPE_CD="
				+ CMPNT_SPCL_PROCRMT_TYPE_CD + ", PRNT_MATL_CNFGRTN_ID=" + PRNT_MATL_CNFGRTN_ID
				+ ", PRNT_MATL_PROCRMT_CD=" + PRNT_MATL_PROCRMT_CD + ", CMPNT_SPLY_PLT_CD=" + CMPNT_SPLY_PLT_CD
				+ ", rowkey=" + rowkey + ", prnt_matl_id=" + prnt_matl_id + ", prnt_matl_plt_cd=" + prnt_matl_plt_cd
				+ ", cmpnt_per_prnt_qty=" + cmpnt_per_prnt_qty + ", prnt_matl_base_uom=" + prnt_matl_base_uom
				+ ", cmpnt_matl_id=" + cmpnt_matl_id + ", cmpnt_matl_uom=" + cmpnt_matl_uom + ", cmpnt_matl_plt_cd="
				+ cmpnt_matl_plt_cd + ", cmpnt_procrmt_type_cd=" + cmpnt_procrmt_type_cd
				+ ", cmpnt_spcl_procrmt_type_cd=" + cmpnt_spcl_procrmt_type_cd + ", prnt_matl_cnfgrtn_id="
				+ prnt_matl_cnfgrtn_id + ", prnt_matl_procrmt_cd=" + prnt_matl_procrmt_cd + ", cmpnt_sply_plt_cd="
				+ cmpnt_sply_plt_cd + "]";
	}
	public static final String  COLUMN_FAMILY ="cf";
	public static final String  ROWKEY = "rowkey";
	public static final String  PRNT_MATL_ID = "prnt_matl_id";
	public static final String  PRNT_MATL_PLT_CD = "prnt_matl_plt_cd";
	public static final String  CMPNT_PER_PRNT_QTY = "cmpnt_per_prnt_qty";
	public static final String  PRNT_MATL_BASE_UOM = "prnt_matl_base_uom";
	public static final String  CMPNT_MATL_ID = "cmpnt_matl_id";
	public static final String  CMPNT_MATL_UOM = "cmpnt_matl_uom";
	public static final String  CMPNT_MATL_PLT_CD = "cmpnt_matl_plt_cd";
	public static final String  CMPNT_PROCRMT_TYPE_CD = "cmpnt_procrmt_type_cd";
	public static final String  CMPNT_SPCL_PROCRMT_TYPE_CD = "cmpnt_spcl_procrmt_type_cd";
	public static final String  PRNT_MATL_CNFGRTN_ID = "prnt_matl_cnfgrtn_id";
	public static final String  PRNT_MATL_PROCRMT_CD = "prnt_matl_procrmt_cd";
	public static final String  CMPNT_SPLY_PLT_CD = "cmpnt_sply_plt_cd";
	
	
	private String rowkey;
	private String prnt_matl_id;
	private String prnt_matl_plt_cd;
	private String cmpnt_per_prnt_qty;
	private String prnt_matl_base_uom;
	private String cmpnt_matl_id;
	private String cmpnt_matl_uom;
	private String cmpnt_matl_plt_cd;
	private String cmpnt_procrmt_type_cd;
	private String cmpnt_spcl_procrmt_type_cd;
	private String prnt_matl_cnfgrtn_id;
	private String prnt_matl_procrmt_cd;
	private String cmpnt_sply_plt_cd;
	
	public String getRowkey() {
		return rowkey;
	}
	public void setRowkey(String rowkey) {
		this.rowkey = rowkey;
	}
	public String getPrnt_matl_id() {
		return prnt_matl_id;
	}
	public void setPrnt_matl_id(String prnt_matl_id) {
		this.prnt_matl_id = prnt_matl_id;
	}
	public String getPrnt_matl_plt_cd() {
		return prnt_matl_plt_cd;
	}
	public void setPrnt_matl_plt_cd(String prnt_matl_plt_cd) {
		this.prnt_matl_plt_cd = prnt_matl_plt_cd;
	}
	public String getCmpnt_per_prnt_qty() {
		return cmpnt_per_prnt_qty;
	}
	public void setCmpnt_per_prnt_qty(String cmpnt_per_prnt_qty) {
		this.cmpnt_per_prnt_qty = cmpnt_per_prnt_qty;
	}
	public String getPrnt_matl_base_uom() {
		return prnt_matl_base_uom;
	}
	public void setPrnt_matl_base_uom(String prnt_matl_base_uom) {
		this.prnt_matl_base_uom = prnt_matl_base_uom;
	}
	public String getCmpnt_matl_id() {
		return cmpnt_matl_id;
	}
	public void setCmpnt_matl_id(String cmpnt_matl_id) {
		this.cmpnt_matl_id = cmpnt_matl_id;
	}
	public String getCmpnt_matl_uom() {
		return cmpnt_matl_uom;
	}
	public void setCmpnt_matl_uom(String cmpnt_matl_uom) {
		this.cmpnt_matl_uom = cmpnt_matl_uom;
	}
	public String getCmpnt_matl_plt_cd() {
		return cmpnt_matl_plt_cd;
	}
	public void setCmpnt_matl_plt_cd(String cmpnt_matl_plt_cd) {
		this.cmpnt_matl_plt_cd = cmpnt_matl_plt_cd;
	}
	public String getCmpnt_procrmt_type_cd() {
		return cmpnt_procrmt_type_cd;
	}
	public void setCmpnt_procrmt_type_cd(String cmpnt_procrmt_type_cd) {
		this.cmpnt_procrmt_type_cd = cmpnt_procrmt_type_cd;
	}
	public String getCmpnt_spcl_procrmt_type_cd() {
		return cmpnt_spcl_procrmt_type_cd;
	}
	public void setCmpnt_spcl_procrmt_type_cd(String cmpnt_spcl_procrmt_type_cd) {
		this.cmpnt_spcl_procrmt_type_cd = cmpnt_spcl_procrmt_type_cd;
	}
	public String getPrnt_matl_cnfgrtn_id() {
		return prnt_matl_cnfgrtn_id;
	}
	public void setPrnt_matl_cnfgrtn_id(String prnt_matl_cnfgrtn_id) {
		this.prnt_matl_cnfgrtn_id = prnt_matl_cnfgrtn_id;
	}
	public String getPrnt_matl_procrmt_cd() {
		return prnt_matl_procrmt_cd;
	}
	public void setPrnt_matl_procrmt_cd(String prnt_matl_procrmt_cd) {
		this.prnt_matl_procrmt_cd = prnt_matl_procrmt_cd;
	}
	public String getCmpnt_sply_plt_cd() {
		return cmpnt_sply_plt_cd;
	}
	public void setCmpnt_sply_plt_cd(String cmpnt_sply_plt_cd) {
		this.cmpnt_sply_plt_cd = cmpnt_sply_plt_cd;
	}
	
	
	
}
