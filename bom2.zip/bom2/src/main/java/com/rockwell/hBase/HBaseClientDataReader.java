package com.rockwell.hBase;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseClientDataReader {

	private static Configuration config = null;
	private static HTable hTable = null;
	
	public static void init() throws IOException {
		config = HBaseConfiguration.create();
		hTable = new HTable(config, "single_level_bom");
	}

	public static void destroy(){
		config = null;
		try {
			hTable.close();
		} catch (IOException e) {
			System.err.println("hTable.close() : "+e.getMessage());
		}
	}
	
	private static byte[] _b(String value) {
		return Bytes.toBytes(value);
	}
	
	public static ArrayList<SingleLevelBom> getFromHBase(String rowKeyPrefix) throws IOException {
		ArrayList<SingleLevelBom> bomList = new ArrayList<SingleLevelBom>();
		ResultScanner rs = null;
		try {

			Scan scan = new Scan();
			scan.setRowPrefixFilter(Bytes.toBytes(rowKeyPrefix));
			
			rs = hTable.getScanner(scan);
			
			rs.forEach((Result result)->{
				SingleLevelBom bom = new SingleLevelBom();
				String rowkey = Bytes.toString(result.getRow());
				bom.setRowkey(rowkey);
				bom.setPrnt_matl_id(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.PRNT_MATL_ID))));
				bom.setPrnt_matl_plt_cd(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.PRNT_MATL_PLT_CD))));
				bom.setCmpnt_per_prnt_qty(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_PER_PRNT_QTY))));
				bom.setPrnt_matl_base_uom(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.PRNT_MATL_BASE_UOM))));
				bom.setCmpnt_matl_id(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_MATL_ID))));
				bom.setCmpnt_matl_uom(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_MATL_UOM))));
				bom.setCmpnt_matl_plt_cd(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_MATL_PLT_CD))));
				bom.setCmpnt_procrmt_type_cd(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_PROCRMT_TYPE_CD))));
				bom.setCmpnt_spcl_procrmt_type_cd(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_SPCL_PROCRMT_TYPE_CD))));
				bom.setPrnt_matl_cnfgrtn_id(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.PRNT_MATL_CNFGRTN_ID))));
				bom.setPrnt_matl_procrmt_cd(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.PRNT_MATL_PROCRMT_CD))));
				bom.setCmpnt_sply_plt_cd(Bytes.toString(result.getValue(_b(SingleLevelBom.COLUMN_FAMILY), _b(SingleLevelBom.CMPNT_SPLY_PLT_CD))));
				
					
				bomList.add(bom);
			});
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally {
			if(rs!=null) {
				rs.close();
			}
			if(hTable!=null) {
				hTable.close();
			}
		}

		
		
		return bomList;
		
	}

	}
