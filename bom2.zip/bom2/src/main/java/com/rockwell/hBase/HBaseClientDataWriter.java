package com.rockwell.hBase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseClientDataWriter {

	private static Configuration config = null;
	private static HTable hTable = null;

	public static void init() throws IOException {
		config = HBaseConfiguration.create();
		hTable = new HTable(config, "single_level_bom");
	}

	public static void destroy(){
		config = null;
		try {
			hTable.close();
		} catch (IOException e) {
			System.err.println("hTable.close() : "+e.getMessage());
		}
	}
	
	private static byte[] _b(String value) {
		return Bytes.toBytes(value);
	}

	public static void pushToHBase(ArrayList<SingleLevelBom> bomList) throws IOException {
		try {
			List<Put> puts = new ArrayList<Put>();
			bomList.forEach(bom->{
				Put put = new Put(_b(bom.getRowkey()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.PRNT_MATL_ID), _b(bom.getPrnt_matl_id()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.PRNT_MATL_PLT_CD), _b(bom.getPrnt_matl_plt_cd()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_PER_PRNT_QTY), _b(bom.getCmpnt_per_prnt_qty()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.PRNT_MATL_BASE_UOM), _b(bom.getPrnt_matl_base_uom()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_MATL_ID), _b(bom.getCmpnt_matl_id()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_MATL_UOM), _b(bom.getCmpnt_matl_uom()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_MATL_PLT_CD), _b(bom.getCmpnt_matl_plt_cd()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_PROCRMT_TYPE_CD), _b(bom.getCmpnt_procrmt_type_cd()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_SPCL_PROCRMT_TYPE_CD), _b(bom.getCmpnt_spcl_procrmt_type_cd()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.PRNT_MATL_CNFGRTN_ID), _b(bom.getPrnt_matl_cnfgrtn_id()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.PRNT_MATL_PROCRMT_CD), _b(bom.getPrnt_matl_procrmt_cd()));
				put.addColumn(_b(bom.COLUMN_FAMILY), _b(bom.CMPNT_SPLY_PLT_CD), _b(bom.getCmpnt_sply_plt_cd()));

				
				puts.add(put);
			});
			hTable.put(puts);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
