package com.rockwell.beans

import org.apache.spark.sql.Row
import com.rockwell.hBase.SingleLevelBom

class BomOutput {
  
  var parentMaterial:String =_
  var parentPlant:String=_
  var componentMaterial:String=_
  var ultimateComponentPlant:String=_
  var componentQuantity:String=_
  var componentActualQuantity:String=_
  var componentUOM:String=_
  var category:String=_
  var hierarchy:String=_

  override def toString():String={
    s"parentMaterial=${parentMaterial},parentPlant=${parentPlant},componentMaterial=${componentMaterial},ultimateComponentPlant=${ultimateComponentPlant},componentQuantity=${componentQuantity},componentActualQuantity=${componentActualQuantity},componentUOM=${componentUOM},category=${category},hierarchy=${hierarchy}"
  }
  
}

class BomHelper {
  var parentMaterial:String =_
  var parentPlant:String=_
  var componentMaterial:String=_
  var componentPlant:String=_
  var componentSourcePlant:String=_
  var derivedSourcePlant:String=_
  var cumulativeParentQuantity:String=_
  var hierarchy:String=""
  var componentProcurementType:String =_
  var componentSpecialProcurementType:String =_
  
  override def toString():String={
    s"parentMaterial=${parentMaterial},parentPlant=${parentPlant},componentMaterial=${componentMaterial},componentPlant=${componentPlant},componentSourcePlant=${componentSourcePlant},derivedSourcePlant=${derivedSourcePlant},cumulativeParentQuantity=${cumulativeParentQuantity},hierarchy=${hierarchy},componentProcurementType=${componentProcurementType},componentSpecialProcurementType=${componentSpecialProcurementType}"
  }
}

class BomContainer{
  var bomHelper : BomHelper = _
  var singleLevelBom : SingleLevelBom = _
  var bomOutput : BomOutput = _
}
/*
object App{
  def main(args: Array[String]): Unit = {
    val bomHelper = new BomHelper
    if(bomHelper.quantity==0.0){
      println(true)
    }else{
      println(bomHelper.quantity)
    }
  }*/