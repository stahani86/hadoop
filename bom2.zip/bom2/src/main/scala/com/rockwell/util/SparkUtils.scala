package com.rockwell.util

import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.SparkSession

object SparkUtils {
  
  
  def getDataFrame(spark:SparkSession,filePath:String,fields: String):Dataset[Row]={
    
    val fieldsList = PropertyUtils.getProperty(fields).split(",").toList
    val fieldsSchema : StructType = StructType(fieldsList.map(column=>StructField(column, DataTypes.StringType)).toSeq)
    val dataFilePath = PropertyUtils.getProperty(filePath)
    println("dataFilePath : "+dataFilePath)
    val dataFrame:Dataset[Row] = spark.read.option("header", "true").option("delimiter", ",").schema(fieldsSchema).csv(dataFilePath)
    dataFrame
  }
  
  def getDataFrame(spark:SparkSession,folderPath:String, files:String,fields: String):Dataset[Row]={
    
    val fieldsList = PropertyUtils.getProperty(fields).split(",").toList
    val fieldsSchema : StructType = StructType(fieldsList.map(column=>StructField(column, DataTypes.StringType)).toSeq)
    val dataFolder = PropertyUtils.getProperty(folderPath)
    println("dataFolder : "+dataFolder)
    val dataFiles = PropertyUtils.getProperty(files)
    println("datafiles : "+files)
    val dataFilePaths = dataFiles.split(",").map(fileName=>dataFolder+"/"+fileName)
    val dataFrame:Dataset[Row] = spark.read.option("header", "true").option("delimiter", ",").schema(fieldsSchema).csv(dataFilePaths:_*)
    dataFrame
  }
}