package com.rockwell.udfs

import scala.util.control.Breaks._

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime

import org.apache.spark.sql.SparkSession

object MyUDFApp {
  def main(args: Array[String]): Unit = {
    val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    System.setProperty("hadoop.home.dir", "D:/others/java/winutils-master/hadoop-2.7.1")
    val spark = SparkSession.builder.master("local[*]").appName("bomApp").getOrCreate()
  
    spark.udf.register("zzworkday", zworkday(_: String, _: Int))
    
    import spark.implicits._
    val list = List((1,"Anil","2019.08.01"),(2,"Bharat","2019.08.23"),(1,"Anil","2019.08.27")).toDF("id","name","joined_date")
    list.show    
    spark.close()
  }

  def zworkday(start_date: String, days: Int): String = {
    var i = 0;
    var tot = 0;
    if (days == 0) start_date;
    if (start_date == null) null;
    breakable {
      while (true) {
        if (days > 0) (i = i + 1) else (i = i - 1);
        val zdate = LocalDate.parse(start_date.toString, DateTimeFormatter.ofPattern("yyyy.MM.dd"));
        val zzdate = zdate.plusDays(i).getDayOfWeek.toString;
        if (zzdate != "SATURDAY" && zzdate != "SUNDAY") (tot = tot + 1);
        if (tot == days) break;
      }
    }
    val zzzdate = LocalDate.parse(start_date.toString, DateTimeFormatter.ofPattern("yyyy.MM.dd")).plusDays(i);
    zzzdate.toString;
  }

}