package com.rockwell

import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession

import com.rockwell.beans.BomContainer
import com.rockwell.beans.BomHelper
import com.rockwell.beans.BomOutput
import com.rockwell.hBase.HBaseClientDataReader
import com.rockwell.hBase.SingleLevelBom
import com.rockwell.util.PropertyUtils

import collection.JavaConverters._
import org.apache.spark.sql.RowFactory

object BomManager {

  val emptyList = List("", " ", null, "null", "NULL")
  val case1SpclProcList = List("10", "20", "40", "50") ::: emptyList
  val case5SpclProcList = List("10", "20", "30", "40", "50") ::: emptyList
  var recordNumber:Long = 0l
  var list: List[(String, String, String, String, String, String, String, String, String, String)] = Nil
  var totalRecords:Long = 0l
  
  def writeDFtoCSV(df: Dataset[Row]): Unit = {
    val outputDataFolderPath = PropertyUtils.getProperty("outputDataFolderPath")
    df.repartition(1).write.mode(SaveMode.Append).option("header", "false").option("delimiter", ",").csv(outputDataFolderPath)
  }

  def processRemainingRecords(spark:SparkSession):Unit={
    if(BomManager.list.size>0){
      val outputFields = PropertyUtils.getProperty("outputDataFields")
      
      import spark.implicits._
      val df = BomManager.list.toDF( outputFields.split(","):_*)
      writeDFtoCSV(df)
      //df.write.insertInto("bom_data")
    }
  }
  
  
  def generateSingleLevelBOMOutputDF(spark:SparkSession,bomOutput:BomOutput):Unit={
    recordNumber = recordNumber+1
    val col0 =  recordNumber.toString()
    val col1 =  bomOutput.parentMaterial
    val col2 =  bomOutput.parentPlant
    val col3 =  bomOutput.componentMaterial 
    val col4 =  bomOutput.ultimateComponentPlant
    val col50 =  bomOutput.componentActualQuantity
    val col5 =  bomOutput.componentQuantity
    val col6 =  bomOutput.componentUOM
    val col7 =  bomOutput.category
    val col8 =  bomOutput.hierarchy+"_"+col3
    list = list ::: List((col0, col1, col2, col3, col4, col50, col5, col6, col7, col8))
    if(list.size==50){
      val outputFields = PropertyUtils.getProperty("outputDataFields")
      import spark.implicits._
      val df =list.toDF( outputFields.split(","):_*)
       writeDFtoCSV(df)
       println(s"Captured 50 Records. Last Record No = ${recordNumber}")
      //df.write.insertInto("bom_data")
      BomManager.list = Nil
    }
  }
  
 def extractBomOutput(bomRow:Row):BomOutput={
    val bomOutput:BomOutput = new BomOutput()
    bomOutput.parentMaterial =  bomRow.getString(bomRow.fieldIndex("prnt_matl_id"))
    bomOutput.parentPlant =  bomRow.getString(bomRow.fieldIndex("prnt_matl_plt_cd"))
    bomOutput.componentMaterial =  bomRow.getString(bomRow.fieldIndex("cmpnt_matl_id"))
    bomOutput.ultimateComponentPlant =  bomRow.getString(bomRow.fieldIndex("cmpnt_matl_plt_cd"))
    bomOutput.componentQuantity = bomRow.getDecimal(bomRow.fieldIndex("cmpnt_per_prnt_qty")).toString()
    bomOutput.componentUOM =  bomRow.getString(bomRow.fieldIndex("cmpnt_matl_uom"))
    bomOutput
  }
 
 def extractBomOutput(singleLevelBom:SingleLevelBom):BomOutput={
    val bomOutput:BomOutput = new BomOutput()
    bomOutput.parentMaterial = singleLevelBom.getPrnt_matl_id
    bomOutput.parentPlant =  singleLevelBom.getPrnt_matl_plt_cd
    bomOutput.componentMaterial =  singleLevelBom.getCmpnt_matl_id
    bomOutput.ultimateComponentPlant =  singleLevelBom.getCmpnt_matl_plt_cd
    bomOutput.componentQuantity =  singleLevelBom.getCmpnt_per_prnt_qty
    bomOutput.componentUOM =  singleLevelBom.getCmpnt_matl_uom
    bomOutput
  }
  
  def generateBomHelper(previousBomHelper:BomHelper):BomHelper={
    val bomHelper:BomHelper = new BomHelper()
    if(previousBomHelper!=null){
      bomHelper.hierarchy = previousBomHelper.hierarchy
      bomHelper.cumulativeParentQuantity = previousBomHelper.cumulativeParentQuantity
    }
    bomHelper
  }
  
  def recordHierarchy(bomHelper:BomHelper, parentMaterial:String, componentMaterial:String ):Unit={
    if(bomHelper.hierarchy == ""){
      bomHelper.hierarchy = parentMaterial
    }
    else{
      bomHelper.hierarchy = if(componentMaterial==null) bomHelper.hierarchy+"_"+parentMaterial else bomHelper.hierarchy+"_"+componentMaterial
    }
  }
  
  def multiply(a:String, b:String):String={
    try{
      val a1:BigDecimal = BigDecimal.valueOf(a.toDouble)
      val b1:BigDecimal = BigDecimal.valueOf(b.toDouble)
      val out:java.math.BigDecimal = (a1 * b1).bigDecimal
      out.toPlainString() 
    }catch {
      case e: Exception => println(s"""Error occured during multiply ${a} * ${b}""")
      null
    }
  }
  
  def recordCumulativeParentQuantity(bomHelper:BomHelper, parentQuantity:String):Unit={
    try{
     if(parentQuantity==null){
       bomHelper.cumulativeParentQuantity = "1"
     }else{
       bomHelper.cumulativeParentQuantity = parentQuantity
     }
    }catch {
      case e: Exception => println(s"""Error occured during recordCumulativeParentQuantity :: bomHelper.cumulativeParentQuantity=${bomHelper.cumulativeParentQuantity}, parentQuantity=${parentQuantity} """)
    }
  }
  
  def processQuantity(bomOutput:BomOutput,bomHelper:BomHelper):String={
    val componentQuantity:String =  bomOutput.componentQuantity 
    val cumulativeParentQuantity:String =  bomHelper.cumulativeParentQuantity 
    //println(s"componentQuantity=$componentQuantity , cumulativeParentQuantity=$cumulativeParentQuantity")
    bomOutput.componentActualQuantity = componentQuantity
    multiply(componentQuantity, cumulativeParentQuantity)
  }
  
  def processSingleLevelBOMRecord(spark:SparkSession, singleLevelBomDF:Dataset[Row], parentMaterial:String, parentPlant:String, componentMaterial:String, componentPlant:String, parentQuantity:String, previousBomHelper:BomHelper):Unit={
  
   /* val condition = if(componentMaterial==null && componentPlant==null) 
                  s" prnt_matl_id='$parentMaterial'	and prnt_matl_plt_cd='$parentPlant'"
                else 
                  s" prnt_matl_id='$componentMaterial'	and prnt_matl_plt_cd='$componentPlant'"
    val bomDF = singleLevelBomDF.where(condition)
    val bomArray:Array[Row] = bomDF.collect()*/
    
    val rowkeyPrefix = if(componentMaterial==null && componentPlant==null) 
                  s"$parentMaterial|$parentPlant|"
                else 
                   s"$componentMaterial|$componentPlant|"
                   val bomArray:Array[SingleLevelBom] = HBaseClientDataReader.getFromHBase(rowkeyPrefix).asScala.toArray[SingleLevelBom]
    
    //println(query)
    val bomRecords:Int = bomArray.length
    //println(s"*******  Entered processSingleLevelBOMRecord and got bomRecords=${bomRecords} ********")
    //bomDF.show()
    val bomContainerArray:Array[BomContainer] = new Array[BomContainer](bomRecords) 
    val bomArrayWithIndex:Array[(SingleLevelBom,Int)]= Array.tabulate(bomRecords) { i => (bomArray(i), i) }
    bomArrayWithIndex.foreach(record=>{
       val singleLevelBom:SingleLevelBom =  record._1
       val index:Int =  record._2
       val bomOutput:BomOutput = extractBomOutput(singleLevelBom)
       bomOutput.parentMaterial = parentMaterial
       bomOutput.parentPlant = parentPlant
       //println("previousBomHelper :: "+previousBomHelper)
       val bomHelper:BomHelper = generateBomHelper(previousBomHelper)
       recordHierarchy(bomHelper, parentMaterial, componentMaterial)
       recordCumulativeParentQuantity(bomHelper, parentQuantity)
       bomHelper.componentProcurementType = singleLevelBom.getCmpnt_procrmt_type_cd
       bomHelper.componentSpecialProcurementType = singleLevelBom.getCmpnt_spcl_procrmt_type_cd
       val bomContainer:BomContainer = new BomContainer()
       bomContainer.singleLevelBom = singleLevelBom
       bomContainer.bomHelper = bomHelper
       bomContainer.bomOutput = bomOutput
       //println("bomOutput :: "+bomOutput)
       //println("bomHelper :: "+bomHelper)
       bomContainerArray(index) = bomContainer
    })
    bomContainerArray.foreach(bomContainer=>{  
      val row:SingleLevelBom = bomContainer.singleLevelBom
      val bomHelper:BomHelper = bomContainer.bomHelper
      val bomOutput:BomOutput = bomContainer.bomOutput
      //cmpnt_procrmt_type_cd	cmpnt_spcl_procrmt_type_cd
      val cmpnt_procrmt_type_cd = bomHelper.componentProcurementType
      val cmpnt_spcl_procrmt_type_cd = bomHelper.componentSpecialProcurementType
      
      //println(s"processing Sales Record : parentMaterial=$parentMaterial, parentPlant:$parentPlant, componentMaterial:$componentMaterial, componentPlant:$componentPlant , parentQuantity=$parentQuantity, cumulativeParentQuantity=${bomHelper.cumulativeParentQuantity}")
      //println(s"Observed : cmpnt_procrmt_type_cd=${cmpnt_procrmt_type_cd} and cmpnt_spcl_procrmt_type_cd=${cmpnt_spcl_procrmt_type_cd}")
      
      // CONFIG MATERIAL check starts
      val configItem = row.getPrnt_matl_cnfgrtn_id
      var isConfigMaterial:Boolean = false
      if(!emptyList.contains(configItem)){
        isConfigMaterial = true
      } 
      // CONFIG MATERIAL check ends
      if(emptyList.contains(cmpnt_procrmt_type_cd) && emptyList.contains(cmpnt_spcl_procrmt_type_cd)){
        //empty case
        //println("Single Level BOM : Empty case")
        bomOutput.hierarchy = bomHelper.hierarchy
        bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper)
        bomOutput.category = "SLB-empty"
        generateSingleLevelBOMOutputDF(spark, bomOutput)
      }
      else if(cmpnt_procrmt_type_cd.trim()=="F" && case1SpclProcList.contains(cmpnt_spcl_procrmt_type_cd.trim())){
        // case I
        //println("Single Level BOM : case I")
        bomOutput.hierarchy = bomHelper.hierarchy
        bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper)
        bomOutput.category = "SLB-case-I"
        generateSingleLevelBOMOutputDF(spark, bomOutput)
      }
      else if(cmpnt_procrmt_type_cd.trim()!="F" && cmpnt_procrmt_type_cd.trim()!="E" ){
        // case II
        //println("Single Level BOM : case II") 
        bomOutput.hierarchy = bomHelper.hierarchy
        bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper) 
        bomOutput.category = "SLB-case-II"
        generateSingleLevelBOMOutputDF(spark, bomOutput)
      }
      else if(cmpnt_procrmt_type_cd.trim()=="E"){
        // case III (Make material)
        //println("Single Level BOM : case III (Make material)") 
        bomOutput.hierarchy = bomHelper.hierarchy
        bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper)
        bomOutput.category = "SLB-case-III"
        generateSingleLevelBOMOutputDF(spark, bomOutput)
        val componentMaterial =  row.getCmpnt_matl_id
        val componentPlant =  row.getCmpnt_matl_plt_cd
        //println(s"Extracted componentMateril=${componentMaterial},componentPlant=${componentPlant}")
        if(!isConfigMaterial) processSingleLevelBOMRecord(spark, singleLevelBomDF, parentMaterial, parentPlant, componentMaterial, componentPlant, bomOutput.componentQuantity, bomHelper)
      }
      else if(cmpnt_procrmt_type_cd.trim()=="F" && cmpnt_spcl_procrmt_type_cd.trim()=="30"){
        // case IV (Make material)
        //println("Single Level BOM :case IV (Make material)")
        bomOutput.hierarchy = bomHelper.hierarchy
        bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper)
        bomOutput.category = "SLB-case-IV"
        generateSingleLevelBOMOutputDF(spark, bomOutput)
        val componentMaterial =  row.getCmpnt_matl_id
        val componentPlant =  row.getCmpnt_matl_plt_cd
        //println(s"Extracted componentMateril=${componentMaterial},componentPlant=${componentPlant}")
        if(!isConfigMaterial) processSingleLevelBOMRecord(spark, singleLevelBomDF, parentMaterial, parentPlant, componentMaterial, componentPlant, bomOutput.componentQuantity, bomHelper)
      }
      else if(cmpnt_procrmt_type_cd.trim()=="F" && !case5SpclProcList.contains(cmpnt_spcl_procrmt_type_cd.trim())){
         // case V Stock transfer material from other Rockwell plant
         //println("Single Level BOM : case V Stock transfer material from other Rockwell plant")
         val sourcePlant = row.getCmpnt_sply_plt_cd
         if(emptyList.contains(sourcePlant)){
            //println(s"Derived firstSourcePlant as not valid")
            bomOutput.hierarchy = bomHelper.hierarchy
            bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper)
            bomOutput.category = "SLB-case-V-InvalidFirstSource"
            generateSingleLevelBOMOutputDF(spark, bomOutput)
         }
         else{
            // work starts here
             //println(s"Derived firstSourcePlant=$firstSourcePlant")
             val componentMaterial =  row.getCmpnt_matl_id
             val componentSourcePlant =  row.getCmpnt_matl_plt_cd
             bomHelper.parentMaterial = parentMaterial
             bomHelper.parentPlant = parentPlant
             bomHelper.derivedSourcePlant = sourcePlant
             bomHelper.componentMaterial = componentMaterial
             bomHelper.componentPlant = componentSourcePlant
             bomOutput.hierarchy = bomHelper.hierarchy
             bomOutput.componentQuantity = processQuantity(bomOutput,bomHelper)
             //processMarcParcRecord(spark, bomHelper, bomOutput, null)
             if(componentSourcePlant == sourcePlant){
               bomOutput.category = "SLB-case-V-SAME_PLANT"
               generateSingleLevelBOMOutputDF(spark, bomOutput)  
             }
             else{
               bomOutput.category = "SLB-case-V-TRANSFER_PLANT"
               generateSingleLevelBOMOutputDF(spark, bomOutput)
               processSingleLevelBOMRecord(spark, singleLevelBomDF, parentMaterial, parentPlant, componentMaterial, bomHelper.derivedSourcePlant, bomOutput.componentQuantity, bomHelper)  
             }
         }
      }
    })
    
  }
 

}