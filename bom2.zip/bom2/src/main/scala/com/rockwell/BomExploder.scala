package com.rockwell

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import org.apache.log4j.Logger
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

import com.rockwell.beans.BomHelper
import com.rockwell.util.LoggerUtils
import com.rockwell.util.PropertyUtils
import com.rockwell.util.SparkUtils
import org.apache.spark.SparkConf
import scala.collection.mutable.HashMap
import com.rockwell.hBase.HBaseClientDataReader
import org.apache.spark.sql.expressions.WindowSpec

object BomExploder {

  val log: Logger = Logger.getLogger(BomExploder.getClass)

  val bomMap:HashMap[String, Row] = new HashMap[String, Row]()
  
  def main(args: Array[String]) {
    val startTime = System.currentTimeMillis()
    val startTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("started at : " + startTimestamp)
    //System.setProperty("hadoop.home.dir", "D:/others/java/winutils-master/hadoop-2.7.1")
    PropertyUtils.initProperties("application.properties")
    //PropertyUtils.initProperties("local.application.properties")
    // Configuring for Log4j
    //LoggerUtils.configure(PropertyUtils.getProperty("log4jConfigPath"))
    
    //Getting spark session
    //val spark = SparkSession.builder.master("local[*]").appName("bomApp").enableHiveSupport().getOrCreate()
    //val conf = new SparkConf
    //conf.set("spark.dynamicAllocation.enabled", "true")
    //conf.set("spark.dynamicAllocation.minExecutors", "1")
    val appName = args(0)
    val startRecordRowNo:Long = args(1).toLong
    val inputChunkSize:Long = args(2).toLong
    var endRecordRowNo:Long = startRecordRowNo+inputChunkSize-1
    val spark = SparkSession.builder.appName(appName).master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    HBaseClientDataReader.init();
    
    /*val salesDataDF = SparkUtils.getDataFrame(spark, "salesDataFilePath", "salesDataFields")
    val singleLevelBomDF = SparkUtils.getDataFrame(spark, "singleLevelBomFolder","singleLevelBomFiles", "singleLevelBomFields")
    val marcParqDF = SparkUtils.getDataFrame(spark, "marcParqFilePath", "marcParqFields")
    val t460aDF = SparkUtils.getDataFrame(spark, "t460aFilePath", "t460aFields")
  */
    
    // give table names with database names here 
    
    val totalSalesDataDF = spark.read.table("default.sales_data_test1")
    val totalSalesRecords:Long = totalSalesDataDF.count()
    endRecordRowNo = if(totalSalesRecords<endRecordRowNo) totalSalesRecords  else endRecordRowNo
    val windowSpec :WindowSpec = Window.orderBy("prnt_matl_id", "prnt_matl_plt_cd")
    val salesDataDF = totalSalesDataDF
                      .select("prnt_matl_id","prnt_matl_plt_cd").coalesce(1)
                      .select(col("prnt_matl_id"), col("prnt_matl_plt_cd") ,row_number().over(windowSpec).as("row_num"))
                      .where(col("row_num").between(startRecordRowNo, endRecordRowNo))   
    val singleLevelBomDF = spark.read.table("q_sap_sds_data.sngl_lvl_bom_by_plt").select("prnt_matl_id","prnt_matl_plt_cd","prnt_matl_base_uom","cmpnt_matl_id","cmpnt_per_bom_qty","cmpnt_per_prnt_qty","cmpnt_matl_uom","cmpnt_matl_plt_cd","cmpnt_procrmt_type_cd","cmpnt_spcl_procrmt_type_cd","prnt_matl_cnfgrtn_id","prnt_matl_procrmt_cd","cmpnt_sply_plt_cd").coalesce(1)
    salesDataDF.persist()
    singleLevelBomDF.persist()
    
    //marcParqDF.persist()
    //t460aParqDF.persist()
    salesDataDF.printSchema()
    println("Sales Data record count = "+salesDataDF.count())
    singleLevelBomDF.printSchema()
    println("Single Level BOM Data record count = "+singleLevelBomDF.count())
    //marcParqDF.printSchema()
    //println("Marq Parq Data record count = "+marcParqDF.count())
    //t460aParqDF.printSchema()
    //println("t460a Data record count = "+t460aParqDF.count())
    
    val outputFields = PropertyUtils.getProperty("outputDataFields")
    val outputSchema = StructType(outputFields.split(",").map(f=>StructField(f, DataTypes.StringType)).toSeq)
    val outputDF = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], outputSchema) 
    
    // BOM recursion logic starts
    //singleLevelBomDF.createTempView("sngl_lvl_bom_by_plt")
    //marcParqDF.createTempView("marc_parq")
    //t460aParqDF.createTempView("t460a_parq")    
    val bomExplosionStartTime = System.currentTimeMillis()
    val bomExplosionStartTimestamp: String = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    println("BomExplosion started at : " + bomExplosionStartTimestamp)
    
    salesDataDF.collect().foreach(row=>{
      val parentMaterial:String = row.getString(row.fieldIndex("prnt_matl_id")) 
      val parentPlant:String = row.getString(row.fieldIndex("prnt_matl_plt_cd"))
      val bomHelper:BomHelper = new BomHelper()
      BomManager.processSingleLevelBOMRecord(spark, singleLevelBomDF, parentMaterial, parentPlant, null, null, null, bomHelper)
    })
    
    BomManager.processRemainingRecords(spark)
    
    val totalTimeConsumedForExplosionInSecs = (System.currentTimeMillis() - bomExplosionStartTime) / 1000
    println(s"Total Time consumed for BomExplosion :  $totalTimeConsumedForExplosionInSecs seconds")
    
    
    salesDataDF.unpersist();
    singleLevelBomDF.unpersist();
    //marcParqDF.unpersist();
    //t460aParqDF.unpersist();
    HBaseClientDataReader.destroy()
    spark.stop();
    
    val totalTimeConsumedInSecs = (System.currentTimeMillis() - startTime) / 1000
    println(s"Total Time consumed :  $totalTimeConsumedInSecs seconds")
    print("Ended at : " + LocalDateTime.now())
  }
}