#!/bin/sh

##kinit

spark2-submit --class com.rockwell.BomExploder \
--driver-memory 5g \
--executor-memory 5g \
--executor-cores 2 \
--num-executors 1 \
 bomExplosion-3.0.jar bomApp1 1 10
 
 
 hdfs dfs -chmod -R 777 hdfs://nameservice1/user/nmogull/bomExplosionReport
 
 
 
